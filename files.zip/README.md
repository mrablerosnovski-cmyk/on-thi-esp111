# ESP111 – Ôn thi Business Studies
Web tĩnh (không cần build). Đẩy lên GitHub → Settings → Pages → Deploy from branch `main` / root.
- `data.js`: thêm từ vựng (`"unit|term|definition"`), đoạn TFNG, câu hỏi ngắn, đề essay.
- Tiến độ "đã thuộc" lưu bằng localStorage.
